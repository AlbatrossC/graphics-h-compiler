#include <graphics.h>
#include <conio.h>
#include <iostream.h>

void main() {
    int gd = DETECT, gm;

    // Path is empty because our HTML script copies the driver
    // to the same folder as the EXE file.
    initgraph(&gd, &gm, "");

    // Draw something
    setcolor(CYAN);
    rectangle(50, 50, 590, 350);
    
    setcolor(YELLOW);
    settextstyle(DEFAULT_FONT, HORIZ_DIR, 2);
    outtextxy(180, 180, "COMPILED AUTOMATICALLY");
    
    setcolor(GREEN);
    outtextxy(210, 220, "(NO BLUE UI!)");

    getch();
    closegraph();
}