#include <graphics.h>
#include <conio.h>

void main() {
    int gd = DETECT, gm;

    // Use standard path now
    initgraph(&gd, &gm, "C:\\BGI");

    if (graphresult() != grOk) {
       // If standard fails, try empty path ""
       initgraph(&gd, &gm, ""); 
    }

    circle(320, 240, 50);
    outtextxy(100, 100, "Fixed!");
    getch();
    closegraph();
}